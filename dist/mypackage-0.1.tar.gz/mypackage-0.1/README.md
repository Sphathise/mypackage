# mypackage
This library was created as an example of how to publish your own Python package.

## Building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+https://github.com/Sphathise/mypackage.git'

## updating this package from Github
'pip install --upgrade git+https://github.com/Sphathise/mypackage.git'